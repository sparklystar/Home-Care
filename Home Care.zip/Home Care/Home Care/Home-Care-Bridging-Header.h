//
//  Home-Care-Bridging-Header.h
//  Home Care
//
//  Created by Tung Nguyen on 09/04/15.
//  Copyright (c) 2015 Metropolia. All rights reserved.
//

#ifndef Home_Care_Home_Care_Bridging_Header_h
#define Home_Care_Home_Care_Bridging_Header_h

#import "MSCellAccessory.h"

#endif